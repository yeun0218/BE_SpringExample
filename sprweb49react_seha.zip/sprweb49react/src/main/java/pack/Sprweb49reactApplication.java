package pack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sprweb49reactApplication {

	public static void main(String[] args) {
		SpringApplication.run(Sprweb49reactApplication.class, args);
	}

}
